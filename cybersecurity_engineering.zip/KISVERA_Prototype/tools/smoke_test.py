"""End-to-end smoke test for the KISVERA prototype. Standard library only.

Needs, running locally:
  1. the backend      (cd backend && uvicorn app.main:app --port 8000)   with KISVERA_ALLOW_PRIVATE=true
  2. the demo site    (python demo/weak_site.py)                          on 127.0.0.1:8081

  python tools/smoke_test.py [http://localhost:8000] [http://127.0.0.1:8081]

It walks the whole flow: login, roles, target + ownership proof, scan, findings, lifecycle,
AI draft + approval, PDF, audit trail. It scans ONLY the local demo site.
"""
import json
import os
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

API = (sys.argv[1] if len(sys.argv) > 1 else "http://localhost:8000").rstrip("/")
SITE = (sys.argv[2] if len(sys.argv) > 2 else "http://127.0.0.1:8081").rstrip("/")
TOKEN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "demo", "kisvera-verify.txt")

passed = failed = 0


def check(name, cond, extra=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"PASS {name}")
    else:
        failed += 1
        print(f"FAIL {name} {extra}")


def call(method, path, token=None, body=None, form=None):
    data, headers = None, {}
    if form is not None:
        data = urllib.parse.urlencode(form).encode()
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    elif body is not None:
        data = json.dumps(body).encode()
        headers["Content-Type"] = "application/json"
    elif method == "POST":
        data = b""
    if token:
        headers["Authorization"] = f"Bearer {token}"
    req = urllib.request.Request(API + path, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            raw = r.read()
            return r.status, raw, r.headers
    except urllib.error.HTTPError as e:
        return e.code, e.read(), e.headers


def jcall(*a, **k):
    status, raw, _ = call(*a, **k)
    try:
        return status, json.loads(raw) if raw else None
    except ValueError:
        return status, None


def login(user, pw):
    s, d = jcall("POST", "/auth/token", form={"username": user, "password": pw})
    return d["access_token"] if s == 200 and d else None


def wait_scan(token, scan_id, timeout=150):
    end = time.time() + timeout
    while time.time() < end:
        s, d = jcall("GET", f"/targets/scans/{scan_id}", token)
        if s == 200 and d["status"] in ("COMPLETED", "FAILED"):
            return d
        time.sleep(1.5)
    return {"status": "TIMEOUT"}


print(f"API {API} | demo site {SITE}\n")
s, _ = jcall("GET", "/")
check("backend reachable", s == 200)

# --- access control -------------------------------------------------------
check("no token -> 401", jcall("GET", "/targets")[0] == 401)
check("wrong password -> 401", jcall("POST", "/auth/token", form={"username": "analyst", "password": "nope"})[0] == 401)
analyst, viewer, admin = login("analyst", "analyst123"), login("viewer", "viewer123"), login("admin", "admin123")
check("analyst, viewer and admin can log in", all([analyst, viewer, admin]))
check("/auth/me returns the role", jcall("GET", "/auth/me", viewer)[1] == {"username": "viewer", "role": "Viewer"})

# --- target registration + ownership --------------------------------------
payload = {"name": "Demo shop", "url": SITE, "verify_method": "file", "authorization_confirmed": True}
check("viewer cannot add a target (403)", jcall("POST", "/targets", viewer, payload)[0] == 403)
check("missing authorization_confirmed -> 400", jcall("POST", "/targets", analyst, {**payload, "authorization_confirmed": False})[0] == 400)
s, t = jcall("POST", "/targets", analyst, payload)
check("analyst adds target", s in (200, 201) and t and t["status"] in ("pending", "verified"), str(t))
tid, token_value = t["id"], t["verify_token"]
if t["status"] == "pending":
    check("scan before verification is refused (403)", jcall("POST", f"/targets/{tid}/scans", analyst)[0] == 403)
    check("verify without proof fails (422)", jcall("POST", f"/targets/{tid}/verify", analyst)[0] == 422)
    with open(TOKEN_FILE, "w") as fh:
        fh.write(token_value + "\n")
    s, t2 = jcall("POST", f"/targets/{tid}/verify", analyst)
    check("verify with the token published succeeds", s == 200 and t2["status"] == "verified", str(t2))
check("target listed as verified", any(x["id"] == tid and x["status"] == "verified" for x in jcall("GET", "/targets", viewer)[1]))

# --- scan -----------------------------------------------------------------
check("viewer cannot start a scan (403)", jcall("POST", f"/targets/{tid}/scans", viewer)[0] == 403)
s, sc = jcall("POST", f"/targets/{tid}/scans", analyst)
check("scan accepted (202, QUEUED)", s == 202 and sc["status"] == "QUEUED", str(sc))
done = wait_scan(analyst, sc["id"])
check("scan COMPLETED", done["status"] == "COMPLETED", str(done))
s, fs = jcall("GET", f"/targets/scans/{sc['id']}/findings", viewer)
check("viewer can read findings", s == 200 and isinstance(fs, list) and len(fs) >= 8, f"{s} {fs if not isinstance(fs, list) else len(fs)}")
if isinstance(fs, list) and fs:
    need = {"check_name", "severity", "details", "framework_mapping", "evidence"}
    check("findings match the front-end contract", all(need <= set(f) for f in fs))
    check("severity values valid", all(f["severity"] in ("low", "medium", "high", "critical") for f in fs))
    check("critical finding present, sorted first", fs[0]["severity"] == "critical")
    check("XSS (script context) found and Verified", any(f.get("check_id") == "XSS-REFL-002" and f.get("status") == "Verified" for f in fs))
    check("banner CVE is a Potential Issue", any(str(f.get("check_id", "")).startswith("CVE-") and f.get("status") == "Potential Issue" for f in fs))
    check("escaped page /c has no finding", not any("/c?" in str(f.get("resource")) for f in fs))
    check("first scan: all findings are new", all(f.get("lifecycle") == "new" for f in fs))

# --- second scan: lifecycle -----------------------------------------------
s, sc2 = jcall("POST", f"/targets/{tid}/scans", analyst)
done2 = wait_scan(analyst, sc2["id"])
check("second scan COMPLETED", done2["status"] == "COMPLETED", str(done2))
s, fs2 = jcall("GET", f"/targets/scans/{sc2['id']}/findings", analyst)
check("second scan: findings are persistent", s == 200 and fs2 and all(f.get("lifecycle") == "persistent" for f in fs2))
s, cmp_ = jcall("GET", f"/targets/scans/{sc2['id']}/compare", analyst)
check("compare: nothing new, nothing closure pending", s == 200 and not cmp_["new"] and not cmp_["closure_pending"] and len(cmp_["persistent"]) == len(fs2))
check("unfinished/unknown scan findings -> 404", jcall("GET", "/targets/scans/does-not-exist/findings", analyst)[0] == 404)

# --- report: AI draft needs a human ---------------------------------------
sid = sc2["id"]
check("viewer cannot draft AI text (403)", jcall("POST", f"/reports/scans/{sid}/ai-draft", viewer)[0] == 403)
check("approve without a draft -> 409", jcall("POST", f"/reports/scans/{sid}/approve-ai", analyst)[0] == 409)
s, pdf0, _ = call("GET", f"/reports/scans/{sid}/pdf", viewer)
check("viewer can download the report (rule-based PDF)", s == 200 and pdf0[:5] == b"%PDF-")
s, dr = jcall("POST", f"/reports/scans/{sid}/ai-draft", analyst)
check("analyst creates an AI draft labelled DRAFT", s == 200 and dr["status"] == "DRAFT" and dr["findings"], str(dr)[:200])
s, ap = jcall("POST", f"/reports/scans/{sid}/approve-ai", analyst)
check("analyst approves the draft", s == 200 and ap["approved"] is True, str(ap))
s, st = jcall("GET", f"/targets/scans/{sid}", viewer)
check("scan status shows ai_approved", s == 200 and st.get("ai_approved") is True, str(st))
s, pdf1, _ = call("GET", f"/reports/scans/{sid}/pdf", analyst)
check("report after approval is a PDF", s == 200 and pdf1[:5] == b"%PDF-")

# --- audit trail ----------------------------------------------------------
check("analyst cannot read the audit trail (403)", jcall("GET", "/admin/audit", analyst)[0] == 403)
s, au = jcall("GET", "/admin/audit", admin)
actions = {a["action"] for a in au} if s == 200 and au else set()
check("audit has target, scan and report actions",
      {"target.registered", "target.verified", "scan.started", "scan.completed", "report.ai_approved", "report.downloaded"} <= actions, str(sorted(actions)))
check("audit has no secrets", "eyJ" not in json.dumps(au) and token_value not in json.dumps(au) if au else False)

print(f"\n{passed} passed, {failed} failed")
sys.exit(1 if failed else 0)
