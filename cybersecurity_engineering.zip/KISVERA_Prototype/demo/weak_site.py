"""A deliberately weak practice website for the KISVERA prototype demo.

LOCAL USE ONLY. It is vulnerable on purpose (missing security headers, old Apache banner,
a cookie without flags, a page that echoes input unescaped, a page that leaks a database error).
Never expose it to a network.

  python demo/weak_site.py            # serves http://127.0.0.1:8081

Ownership proof: it serves /.well-known/kisvera-verify.txt from demo/kisvera-verify.txt.
Put the token the platform shows you into that file (see the README).
"""
import html
import http.server
import os
import sys
from urllib.parse import urlparse, parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(HERE, "kisvera-verify.txt")
PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 8081


class Weak(http.server.BaseHTTPRequestHandler):
    server_version = "Apache/2.4.49"   # old banner on purpose (matches known CVEs)
    sys_version = ""

    def log_message(self, *a):  # keep the console quiet
        pass

    def _send(self, body: str, status=200, ctype="text/html; charset=utf-8", cookie=False):
        data = body.encode()
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        if cookie:
            self.send_header("Set-Cookie", "sid=abc123; Path=/")   # no Secure / HttpOnly / SameSite
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        u = urlparse(self.path)
        v = parse_qs(u.query).get("p", [""])[0]
        if u.path == "/.well-known/kisvera-verify.txt":
            try:
                return self._send(open(TOKEN_FILE).read(), ctype="text/plain")
            except OSError:
                return self._send("not found", 404, "text/plain")
        if u.path == "/":
            return self._send('<h1>Demo shop</h1><a href="/a?p=1">search</a> <a href="/b?p=1">script</a> '
                              '<a href="/c?p=1">safe</a> <a href="/q?id=1">item</a>', cookie=True)
        if u.path == "/a":
            return self._send(f"<p>You searched {v}</p>")                       # reflected, text context
        if u.path == "/b":
            return self._send(f'<script>var q = "{v}";</script>')               # reflected, script context
        if u.path == "/c":
            return self._send(f"<p>You searched {html.escape(v)}</p>")          # properly escaped: no finding
        if u.path == "/q":
            q = parse_qs(u.query).get("id", [""])[0]
            if "'" in q:
                return self._send("You have an error in your SQL syntax near ''' at line 1", 500)
            return self._send("<p>Item 1</p>")
        return self._send("not found", 404)


if __name__ == "__main__":
    print(f"Weak demo site on http://127.0.0.1:{PORT}  (local use only, vulnerable on purpose)")
    http.server.ThreadingHTTPServer(("127.0.0.1", PORT), Weak).serve_forever()
