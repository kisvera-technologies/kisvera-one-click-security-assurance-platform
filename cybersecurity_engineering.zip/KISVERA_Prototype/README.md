# KISVERA One-Click Security Assurance Platform: integrated prototype

Project KIS-SEC-2026-001. Front end (Aazmeer), backend (Abdul), security engine (Ayesha), joined into one working prototype.

```
KISVERA_Prototype/
  frontend/   React + TypeScript UI              (Tier 1)
  backend/    FastAPI: auth, RBAC, targets, scans, reports, audit   (Tier 2)
  engine/     kisvera_engine: Scanner + Assessment Engine  (Tier 3, plain Python package)
  demo/       weak_site.py: a deliberately vulnerable LOCAL practice site to scan
  tools/      smoke_test.py: end-to-end check of the running system
```

How the parts connect: browser -> `frontend` -> REST/JSON -> `backend` -> `engine.run_job(envelope)` (versioned JSON envelope) -> findings stored in SQLite -> back to the UI.
The backend calls the engine through `backend/app/services/engine_adapter.py`. The old `services/scanner.py` and `vuln_scanner.py` are no longer used (the engine replaces them).

## Run it (3 terminals)

**1. Backend** (Python 3.11+)
```
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # then set SECRET_KEY; optionally GEMINI_API_KEY
uvicorn app.main:app --port 8000
```
Creates `kisvera.db` on first start and adds the demo accounts `admin/admin123`, `analyst/analyst123`, `viewer/viewer123`.

**2. Demo target** (a weak practice site, local only)
```
python demo/weak_site.py            # http://127.0.0.1:8081
```

**3. Front end** (Node 18+)
```
cd frontend
cp .env.example .env
npm install
npm run dev                          # http://localhost:5173
```

## Demo walkthrough
1. Sign in as `analyst` / `analyst123`.
2. Register a target: URL `http://127.0.0.1:8081`, ownership proof **File on the site**, tick the authorisation box. The UI shows a token.
3. Publish the token: `echo "<token>" > demo/kisvera-verify.txt`, then press **Verify**. (Before that, Verify fails and a scan is refused: that is the authorization-first rule.)
4. Select the target, **Start scan**. About 10 findings appear: critical CVE/SQL indicators (Potential Issue), XSS (Verified), missing headers, each with CVSS, severity, confidence, status, evidence and framework mapping.
5. Scan again: findings show `persistent`. (`/targets/scans/{id}/compare` also lists `closure_pending`.)
6. **Draft AI explanations**, read the DRAFT, **Approve draft**, then **Generate report** (PDF). Without approval the PDF uses rule-based text only.
7. Sign in as `viewer`: can read results and download reports, but cannot register, scan or approve. Sign in as `admin` and open `GET /admin/audit` (via `/docs`) to see the audit trail.

Automatic check of all of this (with backend and demo site running): `python tools/smoke_test.py`

## What follows the proposal
- Authorization first: scan only after ownership proof; checked again in the worker; the engine refuses unverified, non-http(s) and private/internal targets (private only allowed by `KISVERA_ALLOW_PRIVATE=true`, local testing).
- JWT login, roles Admin / Analyst / Viewer enforced on every endpoint, rate limiting, CORS limited to the front end.
- Scanner collects, engine judges: CVSS v3.1 from written vectors, severity separate from confidence, status Verified / Potential Issue.
- Findings matched by check ID + resource across assessments: new / persistent / closure_pending (never "resolved" without a retest).
- AI is a labelled draft and only enters the report after an Analyst/Admin approves it; it cannot change score, severity, confidence or status; only sanitised text is sent; rule-based fallback if AI is down.
- Append-only audit trail without secrets (`audit_logs`), plus per-scan request logs (`scan_logs`).
- Evidence stored unchanged (full engine finding kept as JSON in `findings.raw`).

## What is NOT in this prototype (from the proposal)
Remediation tracker (owner, priority, due date), retest-based "resolved", charts and trends (Recharts), dark theme with Tailwind, statuses Requires Evidence / Not Applicable, scan states PARTIAL / CANCELLED, cached CVE data, user-management screens (the API exists: `/admin/users`), per-user ownership of targets, HTTPS/HSTS and encrypted stored secrets (hosting stage), Alembic migrations for the new columns (the app adds them itself).

## Status of testing (honest)
Tested here: engine suite (74 checks), engine against the demo site (10 findings), PDF generation with real findings, lifecycle logic, front-end build and Playwright run in mock mode (15 checks), and `tools/smoke_test.py` against a stand-in server that reuses the real engine/adapter/report code (37 checks).
**NOT tested here: the FastAPI backend itself.** FastAPI, SQLAlchemy and the rest could not be installed in the build environment (no internet), so the routers, database and login were only syntax-checked and reviewed. Run `python tools/smoke_test.py` on your machine; expect small fixes on first run.
Also not done: live NVD lookup (needs internet; only tested against a fake server earlier), real Gemini calls, real browser run against the real backend, Vite dev server.

## Security notes
- Your original `backend/.env` contained a real `GEMINI_API_KEY`. It was NOT copied into this folder. If that zip was shared, rotate the key. Put your key in a new `backend/.env` (never commit it; `.gitignore` covers it).
- Demo accounts and `KISVERA_ALLOW_PRIVATE=true` are for local demos only.
- Registration (`POST /auth/register`) is open and creates Analysts; restrict it before any shared use.
- Any signed-in user can read any scan (no per-user ownership yet).
- Scan only systems you own or may test. The demo site is the only target meant for this prototype.

## Proposal note
The proposal text says Flask; Figure 1 and the delivered backend use FastAPI. Align the wording or the backend before the review.
