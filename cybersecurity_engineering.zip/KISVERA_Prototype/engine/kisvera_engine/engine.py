"""Versioned JSON envelope in, versioned JSON envelope out. Use run_job(envelope) from the Flask backend."""
import datetime as dt
import re

from . import assessment, scanner

ENGINE_MODULE_ID = "kisvera.engine"
SCHEMA_VERSION = "1.0"
ENGINE_VERSION = "1.2"
_SUPPORTED = re.compile(r"^1\.\d+$")


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def _out(status, results, limitations, error=None, audit=None):
    env = {"module_id": ENGINE_MODULE_ID, "schema_version": SCHEMA_VERSION, "observed_at": now(),
           "execution_status": status, "results": results, "limitations": limitations}
    if audit is not None:
        env["audit"] = audit          # every request the engine sent, for the audit trail
    if error:
        env["error"] = error
    return env


def run_job(envelope: dict) -> dict:
    """Input:  {module_id:'kisvera.engine', schema_version:'1.x', target:{id, url, verified:true}}
    Output: envelope with results = findings. Never raises for bad input: returns execution_status 'rejected' or 'failed'."""
    if envelope.get("module_id") != ENGINE_MODULE_ID:
        return _out("rejected", [], [], f"Unsupported module_id: {envelope.get('module_id')!r}")
    if not _SUPPORTED.match(str(envelope.get("schema_version", ""))):
        return _out("rejected", [], [], f"Unsupported schema_version: {envelope.get('schema_version')!r}")
    target = envelope.get("target") or {}
    try:
        obs = scanner.collect(target, envelope.get("options") or {})
    except scanner.ScopeError as e:
        return _out("rejected", [], [], str(e))
    except Exception as e:  # engine bug or network problem: report, do not crash the backend
        return _out("failed", [], [], f"{type(e).__name__}: {e}")
    findings, limitations = assessment.assess(obs, envelope.get("options") or {})
    return _out("completed", findings, limitations, audit=obs.get("audit", []))
