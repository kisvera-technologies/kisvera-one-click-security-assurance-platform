"""Assessment Engine: turns raw observations into scored findings.
Rules are data (rules.json). Severity comes ONLY from the CVSS vector. Confidence is stored separately.
False-positive filter: incomplete or off-host evidence is kept as 'Potential Issue' with low confidence, never hidden."""
import datetime as dt
import json
import os
import re

from . import cvss, nvd

RULES = json.load(open(os.path.join(os.path.dirname(__file__), "rules.json"), encoding="utf-8"))
SECURITY_HEADERS = ("content-security-policy", "x-frame-options", "x-content-type-options")
DB_PORTS = {3306: "MySQL", 5432: "PostgreSQL", 6379: "Redis", 27017: "MongoDB"}
LEGACY_PORTS = {21: "FTP", 23: "Telnet", 3389: "RDP"}
VERSION_RE = re.compile(r"(apache|nginx|openssh|iis|php|lighttpd|tomcat|jetty)[/_ -]?(\d+(\.\d+)+)", re.I)


def _finding(check_id, evidence, complete=True, resource="/", extra_details=""):
    r = RULES["rules"][check_id]
    score = cvss.base_score(r["vector"])
    sev = cvss.severity(score)
    if sev is None:
        return None
    return {
        "check_id": check_id,
        "check_name": r["name"],
        "severity": sev,
        "cvss_score": score,
        "cvss_vector": r["vector"],
        "confidence": "high" if complete else "low",
        "status": "Verified" if complete else "Potential Issue",
        "details": (r["details"] + (" " + extra_details if extra_details else "")).strip(),
        "framework_mapping": r["frameworks"],
        "evidence": evidence,
        "resource": resource,
        "recommendation": r["recommendation"],
    }


CVE_DB = json.load(open(os.path.join(os.path.dirname(__file__), "cve_sample.json"), encoding="utf-8"))["entries"]


def _ver(v):
    return tuple(int(x) for x in v.split("."))


def cve_matches(product, version, options=None, lim=None):
    """Live NVD when enabled (falls back to the offline sample and says so), else the offline sample."""
    cfg = (options or {}).get("nvd") or {}
    if cfg.get("enabled"):
        try:
            return nvd.lookup(product, version, cfg)
        except Exception as e:
            if lim is not None:
                lim.append(f"NVD lookup failed ({type(e).__name__}); used the offline CVE sample instead.")
    out = []
    for e in CVE_DB:
        if e["product"] == product.lower() and _ver(e["min"]) <= _ver(version) <= _ver(e["max"]):
            out.append(e)
    return out


def _cve_finding(e, product, version, evidence, resource):
    """Uses the entry's vector; the score comes from the same calculator as every other check."""
    f = _finding("CVE-MATCH", evidence, False, resource)
    score = cvss.base_score(e["vector"])
    f.update(check_id=e["cve"], check_name=f"Known vulnerability {e['cve']} ({product} {version})", cvss_vector=e["vector"],
             cvss_score=score, severity=cvss.severity(score), confidence="medium", status="Potential Issue",
             details=e["summary"] + " Matched from the version banner only; it may be patched without changing the banner. Confirm before acting.")
    return f


def _xss_context(snippet, marker):
    """Judge where the marker landed: inside <script>, inside a tag attribute, or in page text."""
    i = snippet.find(marker)
    before = snippet[:i]
    if before.lower().rfind("<script") > before.lower().rfind("</script"):
        return "script"
    if before.rfind("<") > before.rfind(">"):
        return "attribute"
    return "text"


DOM_SOURCE = re.compile(r"location\.(hash|search|href)|document\.(URL|documentURI|referrer)|window\.name", re.I)
DOM_SINK = re.compile(r"\.(innerHTML|outerHTML)\s*=|document\.write(ln)?\s*\(|\beval\s*\(|insertAdjacentHTML\s*\(", re.I)
DOM_DIRECT = re.compile(r"(innerHTML|outerHTML)\s*=[^;]*(location\.|document\.URL|window\.name)|document\.write(ln)?\s*\([^;]*(location\.|document\.URL)|eval\s*\([^;]*(location\.|window\.name)", re.I)
RISKY_SUBS = ("dev", "test", "staging", "admin", "vpn", "beta")


def assess(obs: dict, options: dict = None) -> tuple:
    """Returns (findings, limitations)."""
    f, lim = [], []
    host = obs["host"]
    h = obs.get("http") or {}
    if h.get("ok"):
        hdr = dict(h["headers"])
        # False-positive filter: evidence must come from the intended host and not from an error page.
        complete = h.get("final_host") == host and h.get("status", 0) < 500 and not h.get("cross_host_redirect")
        note = "" if complete else " (low confidence: the response came from a redirect to another host or an error page)"
        base = f"{h['status']} from {obs['scheme']}://{host}:{obs['port']}/"
        if h.get("cross_host_redirect"):
            lim.append(f"HTTP check: server redirects to {h['cross_host_redirect']}, which is outside the verified scope and was not followed.")
        else:
            if "content-security-policy" not in hdr:
                f.append(_finding("HDR-CSP-001", f"{base}: no Content-Security-Policy header", complete, extra_details=note))
            if "x-frame-options" not in hdr and "frame-ancestors" not in hdr.get("content-security-policy", ""):
                f.append(_finding("HDR-XFO-001", f"{base}: no X-Frame-Options and no frame-ancestors", complete, extra_details=note))
            if "x-content-type-options" not in hdr:
                f.append(_finding("HDR-XCTO-001", f"{base}: no X-Content-Type-Options header", complete, extra_details=note))
            if obs["scheme"] == "https" and "strict-transport-security" not in hdr:
                f.append(_finding("HDR-HSTS-001", f"{base}: no Strict-Transport-Security header", complete, extra_details=note))
            for k, v in h["headers"]:
                if k == "set-cookie":
                    low = v.lower()
                    missing = [n for n, tok in (("Secure", "secure"), ("HttpOnly", "httponly"), ("SameSite", "samesite")) if tok not in low]
                    if obs["scheme"] == "http" and "Secure" in missing:
                        missing.remove("Secure")  # Secure flag is meaningless over plain HTTP
                    if missing:
                        f.append(_finding("CKE-FLAGS-001", f"Set-Cookie '{v.split('=')[0]}' lacks: {', '.join(missing)}", complete, extra_details=note))
            m = VERSION_RE.search(hdr.get("server", "") + " " + hdr.get("x-powered-by", ""))
            if m:
                f.append(_finding("BANNER-VER-001", f"HTTP header discloses '{m.group(0)}'", complete, extra_details=note))
                for e in cve_matches(m.group(1), m.group(2), options, lim):
                    f.append(_cve_finding(e, m.group(1), m.group(2), f"Server header '{m.group(0)}' is in the affected range", "/"))
    else:
        lim.append(f"HTTP check could not run: {h.get('error', 'no response')}")

    p = obs.get("http_plain")
    if p is not None:
        if p and p.get("ok"):
            if p["chain"] and p["chain"][-1]["scheme"] != "https" and not p.get("cross_host_redirect") and p["status"] < 400:
                f.append(_finding("HTTPS-REDIR-001", f"http://{host}/ answered {p['status']} without redirecting to HTTPS", True))
        else:
            lim.append("Plain-HTTP redirect check skipped (port 80 not reachable).")

    t = obs.get("tls")
    if t is not None:
        if not t.get("ok"):
            lim.append(f"TLS check could not run: {t.get('error')}")
        else:
            if t.get("trusted") is False:
                f.append(_finding("TLS-VERIFY-001", f"Certificate verification failed: {t.get('verify_error')}", True))
            na = t.get("not_after")
            if na:
                days = (dt.datetime.fromisoformat(na) - dt.datetime.now(dt.timezone.utc)).days
                if days < 30:
                    f.append(_finding("TLS-EXP-001", f"Certificate notAfter {na[:10]} ({'expired' if days < 0 else f'{days} days left'})", True))
            if t.get("legacy_accepted"):
                f.append(_finding("TLS-PROTO-001", f"Handshake succeeded with {', '.join(t['legacy_accepted'])}", True))

    for r in obs.get("tcp", []):
        if not r["open"]:
            continue
        if r["port"] in DB_PORTS:
            f.append(_finding("PORT-DB-001", f"TCP {r['port']} ({DB_PORTS[r['port']]}) accepted a connection", True, resource=f":{r['port']}"))
        if r["port"] in LEGACY_PORTS:
            f.append(_finding("PORT-LEGACY-001", f"TCP {r['port']} ({LEGACY_PORTS[r['port']]}) accepted a connection", True, resource=f":{r['port']}"))
        m = VERSION_RE.search(r.get("banner", ""))
        if m:
            f.append(_finding("BANNER-VER-001", f"TCP {r['port']} banner discloses '{m.group(0)}'", True, resource=f":{r['port']}"))
            for e in cve_matches(m.group(1), m.group(2), options, lim):
                f.append(_cve_finding(e, m.group(1), m.group(2), f"TCP {r['port']} banner '{m.group(0)}' is in the affected range", f":{r['port']}"))

    u = obs.get("udp_dns") or {}
    if u.get("answered"):
        f.append(_finding("UDP-DNS-001", "UDP 53 returned a valid DNS answer", True, resource=":53/udp"))
    else:
        lim.append("UDP 53: no answer. UDP is unreliable, so silence is not treated as evidence either way.")

    for r in obs.get("reflection", []):
        if r.get("reflected") and r.get("unescaped"):
            ctx = _xss_context(r["snippet"], r["marker"])
            cid = "XSS-REFL-001" if ctx == "text" else "XSS-REFL-002"
            f.append(_finding(cid, f"Parameter '{r['param']}' on {r['path']} came back unescaped in {ctx} context: ...{r['snippet'][-60:].strip()}",
                              True, resource=f"{r['path']}?{r['param']}="))
        elif r.get("reflected"):
            lim.append(f"Parameter '{r['param']}' on {r['path']} is reflected but encoded. Not reported (this is the correct behaviour).")
    if obs.get("reflection") == []:
        lim.append("Reflection probe: the start page has no same-host links with query parameters, so no input was tested.")

    for r in obs.get("sqli", []):
        if r.get("db_error") and not r.get("in_baseline"):
            f.append(_finding("SQLI-ERR-001", f"Parameter '{r['param']}' on {r['path']}: adding a quote produced a database error ('{r['db_error']}')",
                              False, resource=f"{r['path']}?{r['param']}=", extra_details="Reported as Potential Issue: an error message is an indicator only."))
            f[-1]["confidence"] = "medium"
    for blk in obs.get("dom_scripts", []):
        if DOM_SOURCE.search(blk) and DOM_SINK.search(blk):
            direct = bool(DOM_DIRECT.search(blk))
            x = _finding("XSS-DOM-001", "Inline script reads URL data and uses " + DOM_SINK.search(blk).group(0).strip() + (" in the same statement" if direct else " (same script block)"),
                         False, resource="/ (inline script)")
            x["confidence"] = "medium" if direct else "low"
            f.append(x)
            break

    dk = obs.get("dkim")
    if dk and dk["errors"] < len(dk["tried"]) and not dk["found"]:
        f.append(_finding("DNS-DKIM-001", f"No DKIM key at selectors: {', '.join(dk['tried'])}", False, resource=host))
    elif dk and dk["errors"] == len(dk["tried"]):
        lim.append("DKIM check could not run: the DNS resolver did not answer.")
    for sd in obs.get("subdomains", []):
        label = sd["name"].split(".")[0]
        if label in RISKY_SUBS:
            f.append(_finding("SUB-EXPOSED-001", f"{sd['name']} resolves to {', '.join(sd['addresses'])} (listed, not scanned)", True, resource=sd["name"]))
    if obs.get("subdomains"):
        lim.append("Subdomains found (listed, not scanned): " + ", ".join(x["name"] for x in obs["subdomains"]))
    if obs.get("authenticated"):
        lim.append("Authenticated scan: credentials were sent only to the verified host over its own scheme, and are not stored or returned.")

    for key, label in (("spf", "SPF"), ("dmarc", "DMARC")):
        d = obs.get(key)
        if d is None:
            continue
        if "error" in d:
            lim.append(f"{label} check could not run: {d['error']}")
    sp = obs.get("spf")
    if sp and "error" not in sp and not any(t.lower().startswith("v=spf1") for t in sp["txt"]):
        f.append(_finding("DNS-SPF-001", f"TXT records for {host}: {len(sp['txt'])} found, none start with v=spf1", True, resource=host))
    dm = obs.get("dmarc")
    if dm and "error" not in dm:
        rec = [t for t in dm["txt"] if t.lower().startswith("v=dmarc1")]
        if not rec:
            f.append(_finding("DNS-DMARC-001", f"No v=DMARC1 TXT record at _dmarc.{host}", True, resource="_dmarc." + host))
        elif re.search(r"p\s*=\s*none", rec[0], re.I):
            f.append(_finding("DNS-DMARC-002", f"DMARC record: {rec[0]}", True, resource="_dmarc." + host))
    for name in obs.get("skipped", []):
        lim.append(f"Scan time budget reached; '{name}' was skipped.")

    lim += ["Deliberately NOT done: stored XSS and time/blind SQL injection (they write to, or load, the target, which breaks the read-only safety rule).",
            "Heuristic results (DOM XSS, SQL error, banner CVE) are Potential Issues until a person confirms them.",
            "Framework mappings are readiness guidance, not certification."]
    findings = [x for x in f if x]
    order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    findings.sort(key=lambda x: (order[x["severity"]], -x["cvss_score"], x["check_id"]))
    return findings, lim
