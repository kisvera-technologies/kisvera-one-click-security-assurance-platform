"""Optional live CVE lookup against the NVD API 2.0 (options.nvd.enabled). Falls back to the offline sample on any problem.
The score is always recomputed from the NVD CVSS v3.1 vector by cvss.py, so every score in the platform comes from one calculator."""
import json
import urllib.parse
import urllib.request

from . import cvss

CPE = {"apache": "apache:http_server", "nginx": "nginx:nginx", "openssh": "openbsd:openssh", "php": "php:php",
       "lighttpd": "lighttpd:lighttpd", "tomcat": "apache:tomcat", "jetty": "eclipse:jetty",
       "iis": "microsoft:internet_information_services"}
DEFAULT_BASE = "https://services.nvd.nist.gov/rest/json/cves/2.0"
_cache: dict = {}


def lookup(product: str, version: str, cfg: dict) -> list:
    """Returns [{cve, vector, summary}] (max 5, highest score first). Raises on network or format problems."""
    key = (product.lower(), version)
    if key in _cache:
        return _cache[key]
    vendor = CPE.get(product.lower())
    if not vendor:
        return []
    cpe = f"cpe:2.3:a:{vendor}:{version}:*:*:*:*:*:*:*"
    url = (cfg.get("base_url") or DEFAULT_BASE) + "?" + urllib.parse.urlencode({"cpeName": cpe, "noRejected": ""})
    req = urllib.request.Request(url, headers={"User-Agent": "KISVERA-Assessment/1.0", **({"apiKey": cfg["api_key"]} if cfg.get("api_key") else {})})
    with urllib.request.urlopen(req, timeout=float(cfg.get("timeout", 8))) as r:
        data = json.loads(r.read(2_000_000).decode("utf-8"))
    out = []
    for v in data.get("vulnerabilities", []):
        c = v["cve"]
        m = (c.get("metrics", {}).get("cvssMetricV31") or [None])[0]
        if not m:
            continue
        vec = m["cvssData"]["vectorString"]
        desc = next((d["value"] for d in c.get("descriptions", []) if d.get("lang") == "en"), "")
        out.append({"cve": c["id"], "vector": vec, "summary": desc[:300], "score": cvss.base_score(vec)})
    out.sort(key=lambda e: -e["score"])
    _cache[key] = out[:5]
    return _cache[key]
