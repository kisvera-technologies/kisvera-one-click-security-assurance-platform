"""Scanner Engine: collects RAW observations only. It never judges or scores (that is the Assessment Engine's job).
Safety: verified-scope guard, short fixed port list, read-only requests, timeouts, redirect limit, no exploitation."""
import datetime as dt
import html as _html
import http.client
import ipaddress
import os
import re
import secrets
import socket
import ssl
import struct
import threading
import time
from urllib.parse import urlparse, urljoin, urlencode, parse_qsl

_tl = threading.local()


def _log(kind, target, result):
    """Every outgoing request is recorded so a scan is auditable."""
    getattr(_tl, "audit", []).append({"at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"), "kind": kind, "target": target, "result": result})

TIMEOUT = 4.0
MAX_REDIRECTS = 3
MAX_BODY = 200_000   # never read more than this from any response
PAUSE = 0.05  # polite pause between requests (rate limit)
TCP_PORTS = [21, 22, 23, 25, 80, 443, 3306, 3389, 5432, 6379, 8080, 27017]


class ScopeError(Exception):
    """Raised when a scan is requested outside the verified scope."""


def check_scope(target: dict, options: dict = None) -> tuple:
    """Authorization comes first: refuse unless ownership is verified and the URL is plain http(s) to one host.
    Hardening: refuse hosts that resolve to private/loopback/link-local addresses unless the platform explicitly allows it
    (stops a verified name from being pointed at internal systems or cloud metadata services)."""
    options = options or {}
    if target.get("verified") is not True:
        raise ScopeError("Target ownership is not verified. Scan refused.")
    u = urlparse(str(target.get("url", "")))
    if u.scheme not in ("http", "https") or not u.hostname:
        raise ScopeError("Target URL must be http:// or https:// with a host name.")
    if not options.get("allow_private", False):
        try:
            addrs = {a[4][0] for a in socket.getaddrinfo(u.hostname, None)}
        except OSError as e:
            raise ScopeError(f"Host name does not resolve: {e}")
        for a in addrs:
            ip = ipaddress.ip_address(a)
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast or ip.is_unspecified:
                raise ScopeError("Target resolves to a private or internal address. Scan refused by policy.")
    return u.scheme, u.hostname, u.port or (443 if u.scheme == "https" else 80)


def _conn(scheme, host, port):
    if scheme == "https":
        ctx = ssl.create_default_context()
        ctx.check_hostname = False          # certificate trust is judged separately in tls_check
        ctx.verify_mode = ssl.CERT_NONE
        return http.client.HTTPSConnection(host, port, timeout=TIMEOUT, context=ctx)
    return http.client.HTTPConnection(host, port, timeout=TIMEOUT)


def http_fetch(scheme, host, port, path="/", auth=True):
    """GET one page. Follows only SAME-HOST redirects (up to MAX_REDIRECTS); a cross-host redirect is recorded, not followed."""
    chain, cur_scheme, cur_port = [], scheme, port
    for _ in range(MAX_REDIRECTS + 1):
        try:
            c = _conn(cur_scheme, host, cur_port)
            hdrs = {"User-Agent": "KISVERA-Assessment/1.0", "Accept": "*/*"}
            if auth and getattr(_tl, "auth_headers", None):
                hdrs.update(_tl.auth_headers)   # same host only; header VALUES are never logged or returned
            c.request("GET", path, headers=hdrs)
            r = c.getresponse(); body = r.read(MAX_BODY)
            headers = [(k.lower(), v) for k, v in r.getheaders()]
            chain.append({"scheme": cur_scheme, "host": host, "port": cur_port, "path": path, "status": r.status})
            _log("http", f"GET {cur_scheme}://{host}:{cur_port}{path}", r.status)
            c.close()
        except (OSError, http.client.HTTPException) as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}", "chain": chain}
        time.sleep(PAUSE)
        loc = dict(headers).get("location")
        if r.status in (301, 302, 303, 307, 308) and loc:
            nu = urlparse(loc)
            if nu.hostname and nu.hostname != host:
                return {"ok": True, "status": r.status, "headers": headers, "final_host": host, "chain": chain,
                        "cross_host_redirect": nu.hostname}
            cur_scheme = nu.scheme or cur_scheme
            cur_port = nu.port or (443 if cur_scheme == "https" else 80 if cur_scheme == "http" else cur_port)
            path = (nu.path or "/") + (("?" + nu.query) if nu.query else "")
            continue
        return {"ok": True, "status": r.status, "headers": headers, "final_host": host, "chain": chain,
                "body": body.decode("utf-8", "replace")}
    return {"ok": False, "error": "too many redirects", "chain": chain}


def tls_check(host, port):
    out = {"ok": False}
    try:  # 1) strict handshake: is the certificate trusted for this host?
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), TIMEOUT) as s, ctx.wrap_socket(s, server_hostname=host) as t:
            out.update(ok=True, trusted=True, version=t.version(), cert=t.getpeercert())
    except ssl.SSLCertVerificationError as e:
        out.update(ok=True, trusted=False, verify_error=e.verify_message)
    except (OSError, ssl.SSLError) as e:
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}
    # 2) lenient handshake to read the certificate dates and the negotiated version when untrusted
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((host, port), TIMEOUT) as s, ctx.wrap_socket(s, server_hostname=host) as t:
            out["version"] = t.version()
            der = t.getpeercert(binary_form=True)
        if not out.get("cert") and der:
            out["not_after"] = _not_after(der)
        elif out.get("cert"):
            out["not_after"] = dt.datetime.fromtimestamp(ssl.cert_time_to_seconds(out["cert"]["notAfter"]), dt.timezone.utc).isoformat()
    except (OSError, ssl.SSLError):
        pass
    # 3) is a deprecated protocol still accepted? (only reported if the handshake truly succeeds)
    out["legacy_accepted"] = []
    for name, ver in (("TLSv1.0", ssl.TLSVersion.TLSv1), ("TLSv1.1", ssl.TLSVersion.TLSv1_1)):
        try:
            ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
            ctx.minimum_version = ver; ctx.maximum_version = ver
            try: ctx.set_ciphers("ALL:@SECLEVEL=0")
            except ssl.SSLError: pass
            with socket.create_connection((host, port), TIMEOUT) as s, ctx.wrap_socket(s, server_hostname=host):
                out["legacy_accepted"].append(name)
        except (OSError, ssl.SSLError, ValueError):
            pass
    return out


def _not_after(der: bytes):
    """Parse notAfter from a DER certificate without extra libraries (uses ssl helper via PEM round-trip)."""
    import tempfile, os
    pem = ssl.DER_cert_to_PEM_cert(der)
    with tempfile.NamedTemporaryFile("w", suffix=".pem", delete=False) as f:
        f.write(pem); name = f.name
    try:
        info = ssl._ssl._test_decode_cert(name)  # stdlib internal decoder, read-only
        return dt.datetime.fromtimestamp(ssl.cert_time_to_seconds(info["notAfter"]), dt.timezone.utc).isoformat()
    except Exception:
        return None
    finally:
        os.unlink(name)


def tcp_scan(host, ports=TCP_PORTS):
    """Connect checks on a short fixed list. Reads the greeting a service already sends (banner). No exploitation."""
    res = []
    for p in ports:
        try:
            with socket.create_connection((host, p), 1.0) as s:
                s.settimeout(1.0)
                try: banner = s.recv(120).decode("latin-1", "replace").strip()
                except OSError: banner = ""
            res.append({"port": p, "open": True, "banner": banner}); _log("tcp", f"{host}:{p}", "open")
        except OSError:
            res.append({"port": p, "open": False}); _log("tcp", f"{host}:{p}", "closed")
        time.sleep(PAUSE)
    return res


def udp_dns_probe(host):
    """One standard DNS query to UDP 53. UDP is unreliable: silence proves nothing."""
    q = b"\x4b\x49\x01\x00\x00\x01\x00\x00\x00\x00\x00\x00\x07example\x03com\x00\x00\x01\x00\x01"
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.settimeout(1.5); s.sendto(q, (host, 53)); data, _ = s.recvfrom(512)
        return {"answered": data[:2] == b"\x4b\x49"}
    except OSError:
        return {"answered": False}


def dns_lookup(host):
    try:
        return {"addresses": sorted({a[4][0] for a in socket.getaddrinfo(host, None, socket.AF_INET)})}
    except OSError as e:
        return {"error": str(e)}


# ---------------------------------------------------------------- DNS TXT (SPF / DMARC), raw UDP, standard queries only
def _resolver():
    try:
        for line in open("/etc/resolv.conf"):
            if line.startswith("nameserver"):
                return line.split()[1], 53
    except OSError:
        pass
    return None


def _name(buf, off):
    out, jumped, end = [], False, 0
    while True:
        n = buf[off]
        if n == 0:
            off += 1; break
        if n & 0xC0 == 0xC0:
            ptr = struct.unpack(">H", buf[off:off + 2])[0] & 0x3FFF
            if not jumped: end = off + 2
            off, jumped = ptr, True; continue
        out.append(buf[off + 1:off + 1 + n].decode("latin-1")); off += 1 + n
    return ".".join(out), (end if jumped else off)


def dns_query(name, qtype=16, resolver=None):
    """Return {'txt': [strings]} or {'error': ...}. NXDOMAIN/no record gives an empty list (that is a real answer)."""
    resolver = resolver or _resolver()
    if not resolver:
        return {"error": "no DNS resolver available"}
    qid = secrets.randbits(16)
    q = struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 0) + b"".join(bytes([len(x)]) + x.encode() for x in name.split(".")) + b"\x00" + struct.pack(">HH", qtype, 1)
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sk:
            sk.settimeout(2.5); sk.sendto(q, resolver); data, _ = sk.recvfrom(4096)
        _log("dns", f"{'A' if qtype == 1 else 'TXT'} {name} via {resolver[0]}", "answered")
        rid, flags, qd, an, _, _ = struct.unpack(">HHHHHH", data[:12])
        if rid != qid:
            return {"error": "mismatched DNS id"}
        off = 12
        for _ in range(qd):
            _, off = _name(data, off); off += 4
        txt = []
        for _ in range(an):
            _, off = _name(data, off)
            typ, _, _, rdlen = struct.unpack(">HHIH", data[off:off + 10]); off += 10
            if typ == 1 and qtype == 1 and rdlen == 4:
                txt.append(socket.inet_ntoa(data[off:off + 4]))
            if typ == 16 and qtype == 16:
                rd, j = data[off:off + rdlen], 0; parts = []
                while j < len(rd):
                    n = rd[j]; parts.append(rd[j + 1:j + 1 + n].decode("latin-1")); j += 1 + n
                txt.append("".join(parts))
            off += rdlen
        return {"txt": txt, "rcode": flags & 0xF}
    except (OSError, struct.error, IndexError) as e:
        return {"error": f"{type(e).__name__}: {e}"}


# ---------------------------------------------------------------- reflected-input probe (read-only, benign marker)
_LINK = re.compile(r"""(?:href|action)\s*=\s*["']([^"'#]+\?[^"'#]+)["']""", re.I)


def dns_txt(name, resolver=None):
    return dns_query(name, 16, resolver)


def _is_ip(h):
    try: ipaddress.ip_address(h); return True
    except ValueError: return False


def reflection_probe(scheme, host, port, page_html, limit_urls=5, limit_params=3):
    """Finds same-host links with query parameters and sends ONE harmless marker per parameter.
    The marker contains the characters  " ' < >  but no script. It only records whether they come back unescaped, and the
    text around them. No payload is executed, nothing is stored on the target."""
    seen, out = set(), []
    base = f"{scheme}://{host}:{port}/"
    for href in _LINK.findall(page_html or ""):
        u = urlparse(urljoin(base, _html.unescape(href)))
        if u.hostname != host or u.path in seen:
            continue
        seen.add(u.path)
        params = [k for k, _ in parse_qsl(u.query, keep_blank_values=True)][:limit_params]
        for k in params:
            marker = "kvx" + secrets.token_hex(3)
            probe = marker + "\"'<>"
            q = urlencode({**dict(parse_qsl(u.query, keep_blank_values=True)), k: probe})
            r = http_fetch(scheme, host, u.port or port, u.path + "?" + q)
            body = (r.get("body") or "") if r.get("ok") else ""
            i = body.find(marker)
            if i >= 0:
                chunk = body[max(0, i - 80): i + len(probe) + 20]
                out.append({"path": u.path, "param": k, "marker": marker, "reflected": True,
                            "unescaped": probe in body, "snippet": chunk})
            else:
                out.append({"path": u.path, "param": k, "marker": marker, "reflected": False})
        if len(seen) >= limit_urls:
            break
    return out


def _param_urls(page_html, scheme, host, port, limit_urls=5, limit_params=3):
    base = f"{scheme}://{host}:{port}/"
    seen, out = set(), []
    for href in _LINK.findall(page_html or ""):
        u = urlparse(urljoin(base, _html.unescape(href)))
        if u.hostname != host or u.path in seen:
            continue
        seen.add(u.path)
        out.append((u, [k for k, _ in parse_qsl(u.query, keep_blank_values=True)][:limit_params]))
        if len(seen) >= limit_urls:
            break
    return out


SQL_ERRORS = [r"you have an error in your sql syntax", r"warning: mysqli?_", r"unclosed quotation mark", r"sqlstate\[",
              r"pg_query\(\)", r"\bORA-\d{5}", r"sqlite3?\.operationalerror", r"sqlite3::", r"syntax error at or near",
              r"microsoft ole db provider for sql server", r"quoted string not properly terminated"]
_SQL_RE = re.compile("|".join(SQL_ERRORS), re.I)


def sqli_probe(scheme, host, port, page_html):
    """Error-based check only: one read-only GET per parameter with a single quote added.
    Only records whether a database error message appears that was NOT in the normal response. No time-delay or data-extraction payloads."""
    out = []
    for u, params in _param_urls(page_html, scheme, host, port):
        q0 = dict(parse_qsl(u.query, keep_blank_values=True))
        base = http_fetch(scheme, host, u.port or port, u.path + "?" + urlencode(q0))
        base_hit = bool(_SQL_RE.search(base.get("body", "") if base.get("ok") else ""))
        for k in params:
            r = http_fetch(scheme, host, u.port or port, u.path + "?" + urlencode({**q0, k: q0.get(k, "1") + "'"}))
            body = r.get("body", "") if r.get("ok") else ""
            m = _SQL_RE.search(body)
            out.append({"path": u.path, "param": k, "db_error": m.group(0) if m else None, "in_baseline": base_hit, "status": r.get("status")})
    return out


_SCRIPT = re.compile(r"<script\b[^>]*>(.*?)</script>", re.I | re.S)


def dom_scripts(page_html):
    """Raw material for the static DOM-XSS heuristic: the inline script blocks of the start page (capped)."""
    return [m.strip()[:20000] for m in _SCRIPT.findall(page_html or "") if m.strip()][:20]


DKIM_SELECTORS = ["default", "google", "selector1", "selector2", "k1", "mail", "dkim", "s1", "s2", "smtp"]
SUBDOMAINS = ["www", "mail", "dev", "test", "staging", "api", "admin", "vpn", "ftp", "beta", "portal", "app"]


def dkim_probe(host, selectors, resolver):
    found, errors = [], 0
    for sel in selectors:
        r = dns_query(f"{sel}._domainkey.{host}", 16, resolver)
        if "error" in r:
            errors += 1; continue
        if any("v=dkim1" in t.lower() or "p=" in t.lower() for t in r["txt"]):
            found.append(sel)
    return {"found": found, "tried": list(selectors), "errors": errors}


def subdomain_probe(host, names, resolver):
    """Looks only at names UNDER the verified host. They are listed, never scanned (they are outside the verified scope)."""
    res = []
    for n in names:
        r = dns_query(f"{n}.{host}", 1, resolver)
        if "txt" in r and r["txt"]:
            res.append({"name": f"{n}.{host}", "addresses": r["txt"]})
    return res


def collect(target: dict, options: dict = None) -> dict:
    options = options or {}
    scheme, host, port = check_scope(target, options)
    _tl.audit = []
    auth = (options.get("auth") or {}).get("headers") or {}
    _tl.auth_headers = {str(k): str(v) for k, v in auth.items()} if auth else None
    deadline = time.time() + float(options.get("max_seconds", 60))
    obs = {"host": host, "scheme": scheme, "port": port, "dns": dns_lookup(host), "skipped": [], "authenticated": bool(auth)}
    obs["http"] = http_fetch(scheme, host, port)
    if obs["http"].get("ok") and not obs["http"].get("cross_host_redirect"):
        page = obs["http"].get("body", "")
        obs["reflection"] = reflection_probe(scheme, host, port, page)
        obs["sqli"] = sqli_probe(scheme, host, port, page)
        obs["dom_scripts"] = dom_scripts(page)
    if scheme == "https":
        obs["tls"] = tls_check(host, port)
        obs["http_plain"] = http_fetch("http", host, 80, auth=False) if port == 443 else None
    for name, fn in (("tcp", lambda: tcp_scan(host)), ("udp_dns", lambda: udp_dns_probe(host))):
        if time.time() > deadline:
            obs["skipped"].append(name); continue
        obs[name] = fn()
    if not _is_ip(host):
        res = tuple(options["dns_resolver"]) if options.get("dns_resolver") else None
        if time.time() < deadline:
            obs["spf"] = dns_txt(host, res)
            obs["dmarc"] = dns_txt("_dmarc." + host, res)
            obs["dkim"] = dkim_probe(host, options.get("dkim_selectors") or DKIM_SELECTORS, res)
        else:
            obs["skipped"].append("dns")
        if time.time() < deadline:
            obs["subdomains"] = subdomain_probe(host, options.get("subdomain_wordlist") or SUBDOMAINS, res)
    _tl.auth_headers = None   # never keep credentials after the scan
    obs["audit"] = _tl.audit
    return obs
