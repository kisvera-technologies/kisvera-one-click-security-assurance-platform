"""CVSS v3.1 base score calculator (FIRST specification). Same vector -> same score, always."""
import math

AV = {"N": 0.85, "A": 0.62, "L": 0.55, "P": 0.20}
AC = {"L": 0.77, "H": 0.44}
PR_U = {"N": 0.85, "L": 0.62, "H": 0.27}
PR_C = {"N": 0.85, "L": 0.68, "H": 0.50}
UI = {"N": 0.85, "R": 0.62}
CIA = {"H": 0.56, "L": 0.22, "N": 0.0}


def roundup(x: float) -> float:
    i = round(x * 100000)
    return i / 100000.0 if i % 10000 == 0 else (math.floor(i / 10000) + 1) / 10.0


def parse(vector: str) -> dict:
    parts = vector.split("/")
    if parts[0] != "CVSS:3.1":
        raise ValueError("vector must start with CVSS:3.1")
    m = dict(p.split(":") for p in parts[1:])
    for k in ("AV", "AC", "PR", "UI", "S", "C", "I", "A"):
        if k not in m:
            raise ValueError(f"missing metric {k}")
    return m


def base_score(vector: str) -> float:
    m = parse(vector)
    changed = m["S"] == "C"
    iss = 1 - (1 - CIA[m["C"]]) * (1 - CIA[m["I"]]) * (1 - CIA[m["A"]])
    impact = 7.52 * (iss - 0.029) - 3.25 * (iss - 0.02) ** 15 if changed else 6.42 * iss
    pr = (PR_C if changed else PR_U)[m["PR"]]
    expl = 8.22 * AV[m["AV"]] * AC[m["AC"]] * pr * UI[m["UI"]]
    if impact <= 0:
        return 0.0
    raw = 1.08 * (impact + expl) if changed else impact + expl
    return roundup(min(raw, 10))


def severity(score: float):
    """Bands from the proposal: Critical 9.0-10, High 7.0-8.9, Medium 4.0-6.9, Low 0.1-3.9; 0.0 is not a finding."""
    if score >= 9.0: return "critical"
    if score >= 7.0: return "high"
    if score >= 4.0: return "medium"
    if score > 0.0: return "low"
    return None
