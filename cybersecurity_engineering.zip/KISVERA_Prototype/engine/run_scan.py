"""Command line: python3 run_scan.py https://example.com --verified
The --verified flag stands for 'ownership already proven in the platform'. Without it the engine refuses."""
import argparse, json, sys
from kisvera_engine import run_job

ap = argparse.ArgumentParser()
ap.add_argument("url"); ap.add_argument("--verified", action="store_true"); ap.add_argument("--json", action="store_true"); ap.add_argument("--allow-private", action="store_true", help="allow localhost/private addresses (testing only)")
a = ap.parse_args()
env = run_job({"module_id": "kisvera.engine", "schema_version": "1.0", "target": {"id": "cli", "url": a.url, "verified": a.verified}, "options": {"allow_private": a.allow_private}})
if a.json:
    print(json.dumps(env, indent=2)); sys.exit(0)
print(f"status: {env['execution_status']}" + (f"  ({env['error']})" if env.get("error") else ""))
for f in env["results"]:
    print(f"[{f['severity'].upper():8}] {f['cvss_score']:>4}  {f['check_name']}  ({f['status']}, {f['confidence']} confidence)\n           evidence: {f['evidence']}")
for l in env["limitations"]:
    print("note:", l)
