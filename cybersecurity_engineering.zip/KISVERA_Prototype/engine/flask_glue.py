"""EXAMPLE for the backend intern: how to call the engine from Flask. Replace the dicts with your database.
The backend (not the engine) owns verification state: it passes verified=True only for targets whose ownership it has proven."""
import threading, uuid
from flask import Flask, jsonify
from kisvera_engine import run_job

app = Flask(__name__)
TARGETS = {}   # id -> {"url":..., "status":"verified"|...}   (your DB)
SCANS = {}     # id -> {"status":..., "envelope":...}         (your DB)

def _work(scan_id, target):
    SCANS[scan_id]["status"] = "RUNNING"
    env = run_job({"module_id": "kisvera.engine", "schema_version": "1.0",
                   "target": {"id": target["id"], "url": target["url"], "verified": target["status"] == "verified"},
                   "options": {"max_seconds": 60}})   # add "allow_private": True ONLY for local testing
    SCANS[scan_id].update(envelope=env, status={"completed": "COMPLETED", "rejected": "FAILED", "failed": "FAILED"}[env["execution_status"]],
                          error=env.get("error"))

@app.post("/targets/<tid>/scans")
def start_scan(tid):
    t = TARGETS.get(tid)
    if not t: return jsonify(error="Target not found"), 404
    if t["status"] != "verified": return jsonify(error="Target ownership is not verified. Scan refused."), 403
    sid = uuid.uuid4().hex[:8]; SCANS[sid] = {"id": sid, "target_id": tid, "status": "QUEUED"}
    threading.Thread(target=_work, args=(sid, {**t, "id": tid}), daemon=True).start()
    return jsonify(id=sid, target_id=tid, status="QUEUED"), 202

@app.get("/targets/scans/<sid>")
def get_scan(sid):
    s = SCANS.get(sid)
    return jsonify({k: v for k, v in s.items() if k != "envelope"}) if s else (jsonify(error="Scan not found"), 404)

@app.get("/targets/scans/<sid>/findings")
def findings(sid):
    s = SCANS.get(sid)
    if not s: return jsonify(error="Scan not found"), 404
    if s["status"] != "COMPLETED": return jsonify(error="Scan not finished yet"), 409
    # check_name, severity, details, framework_mapping, evidence are the fields the front end shows; extras are kept for the PDF.
    return jsonify(s["envelope"]["results"])
