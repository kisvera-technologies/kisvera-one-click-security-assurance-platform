import http.server, os, sys, threading, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import flask_glue as g
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self): self.send_response(200); self.send_header("Content-Length","0"); self.end_headers()
    def log_message(self,*a): pass
s = http.server.HTTPServer(("127.0.0.1",0),H); threading.Thread(target=s.serve_forever,daemon=True).start()
g.run_job_orig=g.run_job
g.run_job=lambda env: g.run_job_orig({**env,"options":{"allow_private":True}})
g.TARGETS["t1"]={"url":f"http://127.0.0.1:{s.server_port}","status":"verified"}; g.TARGETS["t2"]={"url":"http://127.0.0.1:1","status":"pending"}
c=g.app.test_client(); r=[]
r.append(c.post("/targets/t2/scans").status_code==403)
x=c.post("/targets/t1/scans"); sid=x.get_json()["id"]; r.append(x.status_code==202)
for _ in range(60):
    if c.get(f"/targets/scans/{sid}").get_json()["status"]=="COMPLETED": break
    time.sleep(0.5)
f=c.get(f"/targets/scans/{sid}/findings").get_json()
r.append(isinstance(f,list) and len(f)>0 and all(k in f[0] for k in("check_name","severity","details","framework_mapping","evidence")))
print("glue test:", "PASS" if all(r) else "FAIL", r)
