"""Run: python3 tests/run_tests.py  (no installs; uses only local servers on 127.0.0.1)."""
import http.server, os, shutil, ssl, subprocess, sys, tempfile, threading
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from kisvera_engine import run_job, cvss, assessment

passed = failed = 0
def ok(name, cond):
    global passed, failed
    passed += cond; failed += (not cond); print(("PASS " if cond else "FAIL ") + name)

class Weak(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path.startswith("/offsite"):
            self.send_response(302); self.send_header("Location", "http://example.org/"); self.end_headers(); return
        self.send_response(200); self.send_header("Server", "Apache/2.4.49")
        self.send_header("Set-Cookie", "sid=abc123; Path=/"); self.send_header("Content-Length", "2"); self.end_headers(); self.wfile.write(b"ok")
    def log_message(self, *a): pass

class Hardened(Weak):
    def do_GET(self):
        self.send_response(200)
        for k, v in (("Content-Security-Policy", "default-src 'self'; frame-ancestors 'none'"), ("X-Content-Type-Options", "nosniff"),
                     ("Server", "web"), ("Set-Cookie", "sid=1; Secure; HttpOnly; SameSite=Strict"), ("Content-Length", "2")):
            self.send_header(k, v)
        self.end_headers(); self.wfile.write(b"ok")

class Quiet(http.server.HTTPServer):
    def handle_error(self, request, client_address): pass   # probes close TLS sockets abruptly; ignore the noise
def serve(handler):
    s = Quiet(("127.0.0.1", 0), handler); threading.Thread(target=s.serve_forever, daemon=True).start(); return s
def job(url, verified=True, options=None, **kw):
    return run_job({"module_id": "kisvera.engine", "schema_version": "1.0", "target": {"id": "t", "url": url, "verified": verified},
                    "options": {"allow_private": True, **(options or {})}, **kw})
ids = lambda env: {f["check_id"] for f in env["results"]}

# --- CVSS calculator against published reference values
ok("CVSS 9.8 reference vector", cvss.base_score("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H") == 9.8)
ok("CVSS 6.1 reference (reflected XSS)", cvss.base_score("CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N") == 6.1)
ok("CVSS 10.0 scope-changed", cvss.base_score("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H") == 10.0)
ok("CVSS 0.0 when no impact", cvss.base_score("CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:N") == 0.0)
ok("severity bands", [cvss.severity(x) for x in (9.0, 8.9, 7.0, 6.9, 4.0, 3.9, 0.1, 0.0)] == ["critical", "high", "high", "medium", "medium", "low", "low", None])
ok("all rule vectors valid and scored", all(cvss.base_score(r["vector"]) > 0 for r in assessment.RULES["rules"].values()))
ok("same input, same score (deterministic)", cvss.base_score(assessment.RULES["rules"]["HDR-CSP-001"]["vector"]) == cvss.base_score(assessment.RULES["rules"]["HDR-CSP-001"]["vector"]))

# --- authorization and envelope
e = job("http://127.0.0.1:9", verified=False)
ok("unverified target refused, nothing scanned", e["execution_status"] == "rejected" and e["results"] == [])
ok("bad module_id rejected", run_job({"module_id": "x", "schema_version": "1.0", "target": {}})["execution_status"] == "rejected")
ok("unsupported schema 2.0 rejected", run_job({"module_id": "kisvera.engine", "schema_version": "2.0", "target": {}})["execution_status"] == "rejected")
ok("non-http scheme rejected", job("file:///etc/passwd")["execution_status"] == "rejected")
ok("schema 1.5 accepted", run_job({"module_id": "kisvera.engine", "schema_version": "1.5", "target": {"url": "http://127.0.0.1:9", "verified": True}, "options": {"allow_private": True}})["execution_status"] == "completed")

# --- weak local site
srv = serve(Weak); env = job(f"http://127.0.0.1:{srv.server_port}")
ok("envelope fields", all(k in env for k in ("module_id", "schema_version", "observed_at", "execution_status", "results", "limitations")))
ok("weak site: missing headers found", {"HDR-CSP-001", "HDR-XFO-001", "HDR-XCTO-001"} <= ids(env))
ok("weak site: cookie flags found", "CKE-FLAGS-001" in ids(env))
ok("weak site: version banner found", "BANNER-VER-001" in ids(env))
ok("no HSTS finding over plain http", "HDR-HSTS-001" not in ids(env))
f0 = env["results"][0]
ok("finding has backend fields", all(k in f0 for k in ("check_name", "severity", "details", "framework_mapping", "evidence")))
ok("severity is lowercase word", all(f["severity"] in ("low", "medium", "high", "critical") for f in env["results"]))
ok("framework mapping lists 5 frameworks for CSP", len([f for f in env["results"] if f["check_id"] == "HDR-CSP-001"][0]["framework_mapping"]) == 5)
ok("sorted most severe first", [f["cvss_score"] for f in env["results"]] == sorted((f["cvss_score"] for f in env["results"]), reverse=True))
ok("verified status + high confidence on clean evidence", all(f["status"] == "Verified" and f["confidence"] == "high" for f in env["results"] if not f["check_id"].startswith("CVE-")))
ok("limitations are stated", any("Deliberately NOT done" in l for l in env["limitations"]))

# --- false-positive filter: cross-host redirect is NOT followed and NOT reported as a finding
class Off(Weak):
    def do_GET(self):
        self.send_response(302); self.send_header("Location", "http://example.org/"); self.send_header("Content-Length", "0"); self.end_headers()
s0 = serve(Off); env = job(f"http://127.0.0.1:{s0.server_port}")
ok("cross-host redirect not followed", any("outside the verified scope" in l for l in env["limitations"]) and "HDR-CSP-001" not in ids(env))
# --- low-confidence path: 5xx page keeps findings as Potential Issue
class Err(Weak):
    def do_GET(self): self.send_response(503); self.send_header("Content-Length", "0"); self.end_headers()
s2 = serve(Err); env = job(f"http://127.0.0.1:{s2.server_port}")
pi = [f for f in env["results"] if f["check_id"] == "HDR-CSP-001"]
ok("error page -> Potential Issue, low confidence, still reported", pi and pi[0]["status"] == "Potential Issue" and pi[0]["confidence"] == "low")

# --- hardened site: no header findings
s3 = serve(Hardened); env = job(f"http://127.0.0.1:{s3.server_port}")
ok("hardened site: no header/cookie/banner findings", not ({"HDR-CSP-001", "HDR-XFO-001", "HDR-XCTO-001", "CKE-FLAGS-001", "BANNER-VER-001"} & ids(env)))

# --- open database port is found (a listener that merely accepts connections on 6379)
import socket
try:
    ls = socket.socket(); ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); ls.bind(("127.0.0.1", 6379)); ls.listen(5)
    def _acc():
        try:
            for _ in range(3): ls.accept()
        except OSError: pass
    threading.Thread(target=_acc, daemon=True).start()
    ok("open Redis port reported", "PORT-DB-001" in ids(job(f"http://127.0.0.1:{srv.server_port}")))
    ls.close()
except OSError:
    print("SKIP port 6379 busy")

# --- TLS with a self-signed, already-expired certificate (needs the openssl command)
if shutil.which("openssl"):
    d = tempfile.mkdtemp()
    subprocess.run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", d + "/k.pem", "-out", d + "/c.pem",
                    "-subj", "/CN=localhost", "-days", "1"], capture_output=True, check=True)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.load_cert_chain(d + "/c.pem", d + "/k.pem")
    hs = Quiet(("127.0.0.1", 0), Weak); hs.socket = ctx.wrap_socket(hs.socket, server_side=True)
    threading.Thread(target=hs.serve_forever, daemon=True).start()
    env = job(f"https://127.0.0.1:{hs.server_port}")
    ok("TLS: untrusted self-signed certificate found", "TLS-VERIFY-001" in ids(env))
    ok("TLS: expiring (1-day) certificate found", "TLS-EXP-001" in ids(env))
    ok("TLS: HSTS missing on https", "HDR-HSTS-001" in ids(env))
else:
    print("SKIP TLS tests (openssl command not found)")

# ================= v1.1 hardening tests =================
import struct
# --- policy: private/loopback targets are refused unless the platform allows it
e = job(f"http://127.0.0.1:{srv.server_port}", options={"allow_private": False})
ok("loopback target refused by default policy", e["execution_status"] == "rejected" and "private" in e["error"])
ok("link-local metadata address refused", job("http://169.254.169.254/", options={"allow_private": False})["execution_status"] == "rejected")

# --- CVE matching from a banner (Apache/2.4.49 from the Weak handler)
env = job(f"http://127.0.0.1:{srv.server_port}")
cv = {f["check_id"]: f for f in env["results"] if f["check_id"].startswith("CVE-")}
ok("CVE-2021-42013 matched, critical 9.8", cv.get("CVE-2021-42013", {}).get("severity") == "critical" and cv["CVE-2021-42013"]["cvss_score"] == 9.8)
ok("CVE-2021-41773 matched, high 7.5", cv.get("CVE-2021-41773", {}).get("severity") == "high")
ok("banner CVE is Potential Issue, medium confidence", all(f["status"] == "Potential Issue" and f["confidence"] == "medium" for f in cv.values()))
ok("OpenSSH CVE not matched on Apache", "CVE-2018-15473" not in cv)
ok("critical sorts first", env["results"][0]["severity"] == "critical")

# --- audit trail
ok("audit lists every request", len(env.get("audit", [])) >= 13 and all(k in env["audit"][0] for k in ("at", "kind", "target", "result")))

# --- time budget
env = job(f"http://127.0.0.1:{srv.server_port}", options={"max_seconds": 0})
ok("time budget skips later modules and says so", any("time budget" in l for l in env["limitations"]))

# --- reflected input probe: text / script contexts found, escaped input not reported
import html
class Refl(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        from urllib.parse import urlparse, parse_qs
        u = urlparse(self.path); v = (parse_qs(u.query).get("p") or [""])[0]
        if u.path == "/":
            body = '<a href="/a?p=1">a</a> <a href="/b?p=1">b</a> <a href="/c?p=1">c</a> <a href="/d?p=1">d</a>'
        elif u.path == "/a": body = f"<p>You searched {v}</p>"
        elif u.path == "/b": body = f'<script>var q = "{v}";</script>'
        elif u.path == "/c": body = f"<p>You searched {html.escape(v)}</p>"
        else: body = f'<input value="{v}">'
        self.send_response(200); self.send_header("Content-Length", str(len(body.encode()))); self.end_headers(); self.wfile.write(body.encode())
    def log_message(self, *a): pass
rs = serve(Refl); env = job(f"http://127.0.0.1:{rs.server_port}")
x = {f["resource"]: f for f in env["results"] if f["check_id"].startswith("XSS-")}
ok("XSS text context -> medium (XSS-REFL-001)", x.get("/a?p=", {}).get("check_id") == "XSS-REFL-001" and x["/a?p="]["severity"] == "medium")
ok("XSS script context -> high (XSS-REFL-002)", x.get("/b?p=", {}).get("check_id") == "XSS-REFL-002" and x["/b?p="]["severity"] == "high")
ok("XSS attribute context -> high", x.get("/d?p=", {}).get("check_id") == "XSS-REFL-002")
ok("escaped output NOT reported", "/c?p=" not in x)
ok("encoded reflection explained in limitations", any("encoded" in l for l in env["limitations"]))
ok("probe marker is benign (no script tag sent)", all("<script" not in a["target"].lower() for a in env["audit"]))

# --- SPF / DMARC through a fake local DNS server
def fake_dns(records):
    sk = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); sk.bind(("127.0.0.1", 0)); sk.settimeout(0.3)
    stop = threading.Event()
    def loop():
        while not stop.is_set():
            try: data, addr = sk.recvfrom(512)
            except OSError: continue
            i = 12; labels = []
            while data[i]: labels.append(data[i + 1:i + 1 + data[i]].decode()); i += 1 + data[i]
            name = ".".join(labels); q = data[12:i + 5]; qtype = struct.unpack(">H", data[i + 1:i + 3])[0]
            ans = []
            if qtype == 16:
                for t in records.get(name, []):
                    b = t.encode(); ans.append(struct.pack(">HHIH", 16, 1, 60, len(b) + 1) + bytes([len(b)]) + b)
            elif qtype == 1:
                for a in records.get(("A", name), []):
                    ans.append(struct.pack(">HHIH", 1, 1, 60, 4) + socket.inet_aton(a))
            resp = data[:2] + struct.pack(">HHHHH", 0x8180, 1, len(ans), 0, 0) + q + b"".join(b"\xc0\x0c" + x for x in ans)
            sk.sendto(resp, addr)
    threading.Thread(target=loop, daemon=True).start(); return sk.getsockname(), stop
res, stop = fake_dns({})
env = job(f"http://localhost:{srv.server_port}", options={"dns_resolver": list(res)}); stop.set()
ok("no SPF record found", "DNS-SPF-001" in ids(env))
ok("no DMARC record found", "DNS-DMARC-001" in ids(env))
res, stop = fake_dns({"localhost": ["v=spf1 -all"], "_dmarc.localhost": ["v=DMARC1; p=none; rua=mailto:a@b.c"]})
env = job(f"http://localhost:{srv.server_port}", options={"dns_resolver": list(res)}); stop.set()
ok("SPF present -> no SPF finding", "DNS-SPF-001" not in ids(env))
ok("DMARC p=none -> weak-policy finding only", "DNS-DMARC-002" in ids(env) and "DNS-DMARC-001" not in ids(env))
res, stop = fake_dns({"localhost": ["v=spf1 -all"], "_dmarc.localhost": ["v=DMARC1; p=reject"], "default._domainkey.localhost": ["v=DKIM1; p=A"]})
env = job(f"http://localhost:{srv.server_port}", options={"dns_resolver": list(res)}); stop.set()
ok("healthy mail DNS -> no mail findings", not any(i.startswith("DNS-") for i in ids(env)))
env = job(f"http://localhost:{srv.server_port}", options={"dns_resolver": ["127.0.0.1", 9]})
ok("unreachable resolver -> limitation, no false finding", not any(i.startswith("DNS-") for i in ids(env)) and any("could not run" in l for l in env["limitations"]))

# ================= v1.2 final tests =================
from urllib.parse import urlparse, parse_qs
import json as _json

# --- DKIM
res, stop = fake_dns({"localhost": ["v=spf1 -all"], "_dmarc.localhost": ["v=DMARC1; p=reject"]})
env = job(f"http://localhost:{srv.server_port}", options={"dns_resolver": list(res)}); stop.set()
ok("DKIM: none at common selectors -> low, Potential Issue", [f for f in env["results"] if f["check_id"] == "DNS-DKIM-001"][0]["status"] == "Potential Issue")
res, stop = fake_dns({"localhost": ["v=spf1 -all"], "_dmarc.localhost": ["v=DMARC1; p=reject"], "mysel._domainkey.localhost": ["v=DKIM1; p=XYZ"]})
env = job(f"http://localhost:{srv.server_port}", options={"dns_resolver": list(res), "dkim_selectors": ["mysel"]}); stop.set()
ok("DKIM: custom selector passed in options is found", "DNS-DKIM-001" not in ids(env))

# --- subdomain discovery: risky names reported, listed not scanned
res, stop = fake_dns({"localhost": ["v=spf1 -all"], "_dmarc.localhost": ["v=DMARC1; p=reject"], "default._domainkey.localhost": ["v=DKIM1; p=A"],
                      ("A", "staging.localhost"): ["10.0.0.5"], ("A", "www.localhost"): ["10.0.0.6"]})
env = job(f"http://localhost:{srv.server_port}", options={"dns_resolver": list(res)}); stop.set()
sub = [f for f in env["results"] if f["check_id"] == "SUB-EXPOSED-001"]
ok("subdomain: staging reported, www (normal) not", len(sub) == 1 and sub[0]["resource"] == "staging.localhost")
ok("subdomains are listed in limitations as not scanned", any("not scanned" in l and "www.localhost" in l for l in env["limitations"]))
ok("no request was ever sent to a subdomain", not any("staging" in a["target"] and a["kind"] == "http" for a in env["audit"]))

# --- SQL injection error probe
class Sql(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        u = urlparse(self.path); v = (parse_qs(u.query).get("id") or ["1"])[0]
        if u.path == "/": body = '<a href="/q?id=1">q</a> <a href="/safe?id=1">s</a> <a href="/always?id=1">a</a>'
        elif u.path == "/q": body = "You have an error in your SQL syntax near x at line 1" if v.endswith("'") else "row 1"
        elif u.path == "/always": body = "debug: warning: mysql_ errors are enabled"
        else: body = "row 1"
        self.send_response(200); self.send_header("Content-Length", str(len(body.encode()))); self.end_headers(); self.wfile.write(body.encode())
    def log_message(self, *a): pass
ss = serve(Sql); env = job(f"http://127.0.0.1:{ss.server_port}")
sq = [f for f in env["results"] if f["check_id"] == "SQLI-ERR-001"]
ok("SQLi: error only after quote -> critical 9.1, Potential Issue", len(sq) == 1 and sq[0]["severity"] == "critical" and sq[0]["status"] == "Potential Issue" and sq[0]["confidence"] == "medium")
ok("SQLi: page without error not reported", all(f["resource"] == "/q?id=" for f in sq))
ok("SQLi: error text already in normal page not reported", not any("/always" in f["resource"] for f in sq))
ok("SQLi probe sends only a single quote (no payload words)", not any(w in a["target"].lower() for a in env["audit"] for w in ("union", "sleep", "or 1=1", "--")))

# --- DOM XSS static heuristic
def page_server(body):
    class P(http.server.BaseHTTPRequestHandler):
        def do_GET(self):
            self.send_response(200); self.send_header("Content-Length", str(len(body.encode()))); self.end_headers(); self.wfile.write(body.encode())
        def log_message(self, *a): pass
    return serve(P)
env = job(f"http://127.0.0.1:{page_server('<script>document.getElementById(1).innerHTML = location.hash;</script>').server_port}")
d1 = [f for f in env["results"] if f["check_id"] == "XSS-DOM-001"]
ok("DOM XSS: direct source->sink in one statement, medium confidence", d1 and d1[0]["confidence"] == "medium" and d1[0]["severity"] == "medium")
env = job(f"http://127.0.0.1:{page_server('<script>var h=location.hash; show(h); el.innerHTML = tpl;</script>').server_port}")
d2 = [f for f in env["results"] if f["check_id"] == "XSS-DOM-001"]
ok("DOM XSS: source and sink only in same block -> low confidence", d2 and d2[0]["confidence"] == "low")
env = job(f"http://127.0.0.1:{page_server('<script>el.innerHTML = tpl;</script><script>var h=location.hash;</script>').server_port}")
ok("DOM XSS: source and sink in different scripts -> not reported", "XSS-DOM-001" not in ids(env))

# --- live NVD lookup (fake NVD server) and fallback
from kisvera_engine import nvd
class FakeNvd(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        body = _json.dumps({"vulnerabilities": [{"cve": {"id": "CVE-9999-0001", "descriptions": [{"lang": "en", "value": "Test vulnerability."}],
            "metrics": {"cvssMetricV31": [{"cvssData": {"vectorString": "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H", "baseScore": 9.8}}]}}}]})
        self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body.encode())
    def log_message(self, *a): pass
nv = serve(FakeNvd); nvd._cache.clear()
env = job(f"http://127.0.0.1:{srv.server_port}", options={"nvd": {"enabled": True, "base_url": f"http://127.0.0.1:{nv.server_port}/"}})
live = [f for f in env["results"] if f["check_id"] == "CVE-9999-0001"]
ok("NVD live: CVE from API used, score recomputed from vector (9.8 critical)", live and live[0]["cvss_score"] == 9.8 and live[0]["severity"] == "critical")
nvd._cache.clear()
env = job(f"http://127.0.0.1:{srv.server_port}", options={"nvd": {"enabled": True, "base_url": "http://127.0.0.1:9/"}})
ok("NVD down -> falls back to offline sample and says so", any("NVD lookup failed" in l for l in env["limitations"]) and "CVE-2021-42013" in ids(env))
nvd._cache.clear()

# --- authenticated scanning: credentials reach the verified host only, never leave in the output
seen = []
class Rec(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        seen.append(self.headers.get("Authorization")); self.send_response(200); self.send_header("Content-Length", "0"); self.end_headers()
    def log_message(self, *a): pass
rc = serve(Rec); SECRET = "Bearer s3cr3t-token-123"
env = job(f"http://127.0.0.1:{rc.server_port}", options={"auth": {"headers": {"Authorization": SECRET}}})
ok("auth: header sent to the verified host", SECRET in seen)
ok("auth: secret never appears in the returned envelope", "s3cr3t" not in _json.dumps(env))
ok("auth: stated in limitations", any("Authenticated scan" in l for l in env["limitations"]))
seen.clear(); job(f"http://127.0.0.1:{rc.server_port}")
ok("no auth option -> no header sent", all(x is None for x in seen))
from kisvera_engine import scanner as _sc
seen.clear(); _sc._tl.auth_headers = {"Authorization": SECRET}
_sc.http_fetch("http", "127.0.0.1", rc.server_port, auth=False); _sc._tl.auth_headers = None
ok("auth=False requests (plain-HTTP twin) never carry credentials", seen == [None])
ok("credentials are cleared after the scan", getattr(_sc._tl, "auth_headers", None) is None)

# --- weak TLS version (synthetic observation: modern OpenSSL refuses TLS 1.0 here)
fnd, _ = assessment.assess({"host": "h", "scheme": "https", "port": 443, "tls": {"ok": True, "trusted": True, "legacy_accepted": ["TLSv1.0"]}})
ok("weak TLS: TLS 1.0 accepted -> finding", [f["check_id"] for f in fnd] == ["TLS-PROTO-001"])
fnd, _ = assessment.assess({"host": "h", "scheme": "https", "port": 443, "tls": {"ok": True, "trusted": True, "legacy_accepted": []}})
ok("weak TLS: nothing legacy accepted -> no finding", not fnd)
ok("23+ rules all score above zero", all(cvss.base_score(r["vector"]) > 0 for r in assessment.RULES["rules"].values()) and len(assessment.RULES["rules"]) >= 23)

print(f"\n{passed} passed, {failed} failed"); sys.exit(1 if failed else 0)
