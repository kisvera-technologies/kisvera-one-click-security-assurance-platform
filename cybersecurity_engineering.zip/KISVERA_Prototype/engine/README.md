# KISVERA Security Engine v1.2 FINAL (cybersecurity engineer module)

Two separate modules, as in the proposal: the **Scanner** collects raw observations (`scanner.py`); the **Assessment Engine** judges them (`assessment.py`).
Pure Python 3 standard library. Nothing to install.

    python3 tests/run_tests.py          # 74 checks, local test servers only (no internet needed)
    python3 tests/glue_test.py          # Flask example (needs Flask)
    python3 run_scan.py https://YOUR-OWN-SITE --verified      # add --allow-private only for localhost testing

## How a result is decided (answers "why is it high but not critical?")
1. Scanner records evidence (e.g. response had no CSP header).
2. A rule in `rules.json` names the check and gives a fixed **CVSS v3.1 vector**.
3. `cvss.py` computes the base score from the vector (FIRST formula). Same evidence, same score.
4. Score -> severity: 9.0-10 critical, 7.0-8.9 high, 4.0-6.9 medium, 0.1-3.9 low; 0.0 is not reported.
5. **Confidence is separate.** False-positive filter: evidence from another host or an error page is kept as `Potential Issue`, low confidence. Nothing is hidden.
6. Framework mapping (OWASP, CIS v8, NIST CSF 2.0, ISO 27001:2022, SOC 2) is readiness guidance, not certification.

## Safety and hardening
- Refuses unless the job says `verified: true` (the backend decides; ownership proof is its job).
- Refuses hosts that resolve to private, loopback or link-local addresses (blocks pointing a verified name at internal systems or cloud metadata). `options.allow_private=true` is for testing only.
- http/https only; one host; same-host redirects only (max 3); read-only GET requests; 4 s timeouts; 200 KB response cap; fixed 12-port list; `options.max_seconds` budget (default 60).
- The reflection probe sends one benign marker (`kvx...\"'<>`) per parameter, max 5 pages x 3 parameters. No script is sent, nothing is stored on the target.
- Every request is returned in `audit` (time, kind, target, result) for the audit trail.
- Doubtful evidence (error page, other host, banner-only CVE match) is kept as `Potential Issue` with lower confidence, never hidden.

## Contract with the backend (versioned envelope)
Input: `{"module_id":"kisvera.engine","schema_version":"1.0","target":{"id","url","verified":true}}`
Output: `{module_id, schema_version, observed_at, execution_status: completed|rejected|failed, results:[Finding], limitations:[...], error?}`
Finding: `check_name, severity (low|medium|high|critical), details, framework_mapping (list of strings), evidence` plus `check_id, cvss_score, cvss_vector, confidence, status, resource, recommendation`.
Wrong `module_id` or a non-1.x `schema_version` is rejected, never guessed.

## Checks implemented (23 rules + live or offline CVE matches)
| Area | What it does | Severity (from CVSS vector) |
|---|---|---|
| HTTP | CSP, X-Frame-Options, X-Content-Type-Options, HSTS, cookie flags, HTTP->HTTPS redirect, version banners | low-medium |
| XSS | Reflected input (text = medium 6.1; script/attribute = high 8.2; encoded output not reported); static DOM-XSS heuristic (medium, low/medium confidence) | medium-high |
| SQL injection | Error-based only: one quote per parameter, reports a DB error that is not in the normal page (critical 9.1, Potential Issue, medium confidence) | critical |
| CVE | Banner version -> CVE. `options.nvd.enabled=true` = live NVD API 2.0 (score recomputed from the NVD vector); otherwise or on failure the offline sample | by vector |
| DNS / mail | SPF, DMARC (missing, p=none), DKIM at 10 common selectors (+ `options.dkim_selectors`) | low-medium |
| Subdomains | 12 common names under the verified host; risky ones (dev/test/staging/admin/vpn/beta) reported. Listed, **never scanned** | low |
| TLS | Certificate trust, expiry (<30 days), TLS 1.0/1.1 accepted | medium |
| Network | TCP fixed port list (database 8.2 high, legacy FTP/Telnet/RDP 7.3 high), UDP 53 | medium-high |

Optional job `options`: `allow_private` (testing only), `max_seconds`, `dns_resolver [host,port]`, `dkim_selectors`, `subdomain_wordlist`,
`nvd {enabled, base_url, api_key}`, `auth {headers:{...}}` (authenticated scan: sent only to the verified host over its own scheme, never to the plain-HTTP twin, never logged or returned, cleared after the scan).

## Deliberately NOT done (and why, say this in the demo)
- **Stored XSS** and **time-based / blind SQL injection**: they must write data to the target or put load on its database. That breaks the read-only safety rule, so they need a signed test agreement and a staging target, not a one-click scan.
- DKIM with an unknown selector (cannot be found without being told the name).
- Anything past reading: exploitation, brute force, denial-of-service tests.

## Known limits (honest)
- Heuristic results (DOM XSS, SQL error, banner CVE, missing DKIM) are Potential Issues until a person confirms them.
- The offline CVE file is a 3-entry sample; the live NVD lookup is tested against a fake NVD server here, not the real one (no internet in the test sandbox). Test it once with internet before the demo.
- The weak-TLS check is tested with a synthetic observation (modern OpenSSL refuses TLS 1.0/1.1 on most machines).
- The probe crawls only the start page's links (max 5 pages x 3 parameters).
