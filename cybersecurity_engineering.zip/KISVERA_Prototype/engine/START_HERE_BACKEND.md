# START HERE: Guide for the Backend Intern

This is the **KISVERA Security Engine**. It scans a website for common security problems and returns a list of findings.
It is for the **prototype**. You do not write any scan logic. You only call the engine from Flask.
(The full technical details are in `README.md`. This file is the short version.)

## 1. What is in this folder

| File / folder | What it is | What you do with it |
|---|---|---|
| `kisvera_engine/` | The actual engine (Scanner + Assessment) | **Copy into your backend project. Do not edit.** |
| `flask_glue.py` | Example of the 3 scan routes in Flask | **Copy the logic into your own app.** Replace the dicts with your database. |
| `run_scan.py` | Run a scan from the command line | For quick testing only |
| `tests/` | `run_tests.py` (74 checks), `glue_test.py` (Flask test) | Run before the demo |
| `README.md` | Full technical documentation | Read if you want details |

Pure Python 3, nothing to install (Flask is needed only for `flask_glue.py` and `glue_test.py`).

## 2. How the engine works (two modules)

1. **Scanner** (`scanner.py`) only collects evidence from the target: HTTP headers, XSS and SQL-injection probes, DNS/mail records (SPF, DMARC, DKIM), subdomains, TLS, open ports. It never judges.
2. **Assessment Engine** (`assessment.py`) matches the evidence to rules in `rules.json`, computes a CVSS v3.1 score (`cvss.py`) and sets the severity. Doubtful results are marked "Potential Issue" with lower confidence. Nothing is hidden.

## 3. The one function you call

```python
from kisvera_engine import run_job

result = run_job({
    "module_id": "kisvera.engine",
    "schema_version": "1.0",
    "target": {"id": "t1", "url": "https://example.com", "verified": True}
})
```

`result["execution_status"]` is one of `completed`, `rejected`, `failed`.
Findings are in `result["results"]`. It never raises an error for bad input.

## 4. IMPORTANT: the `verified` rule

The engine **refuses to scan** unless `verified` is `True`.
**Your backend decides this.** Send `True` only for targets whose ownership your backend has verified. The engine does not check ownership itself.

## 5. The routes the frontend calls

| Route | What it does |
|---|---|
| `POST /targets/<tid>/scans` | Start a scan. Return 403 if the target is not verified. Run the scan in a background thread. Return `{id, target_id, status: "QUEUED"}` (202). |
| `GET /targets/scans/<sid>` | Scan status: `QUEUED`, `RUNNING`, `COMPLETED`, `FAILED`. The frontend polls this every 1.5 s. |
| `GET /targets/scans/<sid>/findings` | The findings list. Return 409 if the scan is not `COMPLETED` yet. |

These three are already written in `flask_glue.py`.
Status mapping: engine `completed` -> `COMPLETED`; `rejected` and `failed` -> `FAILED`.

Fields the frontend shows: `check_name`, `severity`, `details`, `framework_mapping`, `evidence`.
Keep the other fields (`cvss_score`, `recommendation`, ...). The PDF report needs them.

## 6. What is NOT in this folder (you must build it)

- Login (`/auth/token`), add target (`POST /targets`), target verification
- Report PDF route (`GET /reports/scans/{id}/pdf`)
- A real database (`flask_glue.py` keeps targets and scans in memory, so a restart wipes them)
- CORS, if the frontend runs on another port (`flask-cors` or a Vite proxy)

## 7. Testing

```
python3 tests/run_tests.py     # 74 checks, no internet needed
python3 tests/glue_test.py     # Flask example (needs Flask)
python3 run_scan.py https://YOUR-OWN-SITE --verified
```

- To scan localhost, pass `"options": {"allow_private": True}`. **Testing only. Never in production.**
- Only scan sites you own or have permission to scan.
- The live CVE lookup (`options.nvd.enabled`) has only been tested against a fake server. **Test it once with internet before the demo.**

## 8. What the engine will NOT do (on purpose)

No exploitation, stored XSS, blind SQL injection, brute force or denial-of-service. It sends read-only GET requests only, refuses private/internal addresses, and logs every request in `audit`.
